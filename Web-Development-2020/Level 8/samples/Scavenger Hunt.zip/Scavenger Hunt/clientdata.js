/*
	The data for Scavenging Hunt is stored in a series of text files.
	
		There is one file that holds all of the users and their passwords.
		There is one file that lists all of the rooms in the house.
		There is a file for each room. That file holds all of the information for that single room.
		There is a file for each user.  That file holds all of the scavenging information for that user.
*/
var fs = require ('fs');
var url = require("url");
var qs = require("querystring");
var login = require("./login");

/*
	getRandomObject
	
	This function pulls a random object from a file that contains a semi-colon delimited list of strings.
	
	Parameters:
		filename - the name of the file that contains the strings.
		arguments - arguments is a parameter that exists in all functions - additional arguments passed into the function are stored, one by one, into the arguments array.
					arguments here is used to receive strings that may be excluded from the search.
					
	Returns:
		A random item from the room.
*/
function getRandomObject(filename)
{
	var fileData = fs.readFileSync("data/" + filename);
	fileData = fileData.toString().split(";");
	
	/*
		The list of rooms has been pulled from the file.  Remove any rooms that are listed as exceptions.
	*/
	for (var i in arguments)
	{
		let idx = fileData.indexOf(arguments[i]);
		if (idx >= 0)
			fileData.splice(idx, 1);
	}
	
	return fileData[Math.floor(Math.random() * fileData.length)];
}

/*
	getAllItems
	
	Creates a comprehensive list of all of the items in the house.
	
	Returns
		the list of items.
*/
function getAllItems()
{
	var items = [];
	
	/*
		Get a list of the rooms from the allrooms.txt file.
		Load each room individually and add all of its items to the array.
	*/
	var roomData = fs.readFileSync("data/allrooms.txt").toString().split(";");
	for (var i in roomData)
	{
		let room = loadObject(roomData[i] + ".txt");
		items = items.concat(room.items);
	}
	
	return items;
}

/*
	buildUser
	
	Create a new scavenger in the house and write a text file for them.
	
	Parameters:
		uname - the identifying username for the scavenger.
*/
function buildUser(uname)
{
	var user = {};
	user.uname = uname;
	user.room = getRandomObject("allrooms.txt");
	
	var room = loadObject(user.room.room + ".txt");
	
	var itmList = getAllItems();
	user.goal = itmList[Math.floor(Math.random() * itmList.length)];
	user.item = "";
	fs.writeFileSync("data/" + uname + ".txt", JSON.stringify(user));
}

/*
	changeUserData
	
	Changes the value of one property for the user and rewrites that user's text file.
	
	Parameters
		filename - the name of the user's text file.
		changeField - the name of the property that is to be changed.
		change - the new value for the property.
*/
function changeUserData(filename, changeField, change)
{
	var user = loadObject(filename);
	user[changeField] = change;
	fs.writeFileSync("data/" + filename, JSON.stringify(user));
}


/*
	loadObject
	
	Reads an object string from its text file and converts it to an object.
	
	Parameters
		filename - the name of the text file
		
	Returns
		a JSON object representing the string in the text file
*/
function loadObject(filename)
{
	if (!fs.existsSync("data/" + filename))
		return null;
	
	var fileData = fs.readFileSync("data/" + filename);
	fileData = fileData.toString();
	return JSON.parse(fileData);
}

/*
	getTextData
	
	Loads a text file and returns the object as a string.
	
	Parameters
		filename - the name of the text file
		
	Returns
		the stringified object.
*/
function getTextData(filename)
{
	return JSON.stringify(loadObject(filename));
}

/*
	changeUserItem
	
	When the user picks up a new item, this will change what the user has listed as their item.  It will also add the user's old item to the room.
	
	Parameters
		filename - the user's file
		itm - the item the user is picking up
*/
function changeUserItem(filename, itm)
{
	//Load both the user and the room.
	var user = loadObject(filename);
	var room = loadObject(user.room + ".txt");
	
	/*
		If the user isn't holding an item, nothing goes into the room.  Otherwise, the user's current item is added to the room.
	*/
	if (user.item != "")
		room.items.splice(room.items.indexOf(itm), 1, user.item);
	else
		room.items.splice(room.items.indexOf(itm), 1);
		
	user.item = itm;
	
	//Write the new user file and the new room file.
	fs.writeFileSync("data/" + filename, JSON.stringify(user));
	fs.writeFileSync("data/" + room.room + ".txt", JSON.stringify(room));
}

/*
	changeUserGoal
	
	Create a new goal for the user based on what's avaiable in the house.
	
	Parameters
		filename - the name of the  user's text file.
*/
function changeUserGoal(filename)
{
	var user = loadObject(filename);
	var itmList = getAllItems();
	changeUserData(filename, "goal", itmList[Math.floor(Math.random() * itmList.length)]);
}


//EXPORT FUNCTIONS

/*
	getClientData
	
	This functions job is parse the server GET requests and handle the specific jobs of the page.  It parses the data from the query string and calls a function based on the request.
	
	Parameters:
		pathname - the file being loaded or the name of the request being served.
		request - the request object sent to the server.
		
	Returns:
		The information retrieved from the server or "" if there is none.
*/
exports.getClientData = function(pathname, request)
{
	var qobj = qs.parse(url.parse(request.url).search.substring(1));
	if (pathname == "userdata")
	{
		if (!fs.existsSync("data/" + qobj.uname + ".txt"))
			buildUser(qobj.uname);
	
		return getTextData(qobj.uname + ".txt");
	}
	
	if (pathname == "roomdata")
		return getTextData(qobj.room + ".txt");
	
	if (pathname == "changeroom")
		changeUserData(qobj.uname + ".txt", "room", qobj.room);
	
	if (pathname == "changeitem")
		changeUserItem(qobj.uname + ".txt", qobj.item);
	
	if (pathname == "changegoal")
		changeUserGoal(qobj.uname + ".txt");
	
	return "";
}


/*
	handlePostData
	
	This function parses and fulfills all of the requests sent to the server using the POST method.  Instead of returning information, this function handles all of the necessary functions itself and ends the response.
	
	Parameters:
		request:  the request object sent to the server.
		response: the response object returned from the server.
*/
exports.handlePostData = function(request, response)
{
	request.on("data", function(qstr)
	{
		var qobj = qs.parse(qstr.toString());
		
		if (qobj.source == "login")
			var responseData = login.checkForLogin(qobj);
		
		if (qobj.source == "register")
			var responseData = login.registerUser(qobj);
		
		if (responseData)
			response.write("\n<script>data = " + JSON.stringify(responseData) + ";</script>");
		else
			response.write("\n<script>data = null;</script>");
		
		response.end();
	});
}
