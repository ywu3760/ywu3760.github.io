var fs = require("fs");

exports.checkForLogin = function(loginInfo)
{
	var loginData = fs.readFileSync("data/users.txt");
	loginData = loginData.toString().split(";");
	for (var i = 0; i < loginData.length; i++)
	{
		var dataObj = JSON.parse(loginData[i]);
		
		if (dataObj.uname == loginInfo.uname && dataObj.pword == loginInfo.pword)
		{
			console.log(loginInfo.uname + " found. Login successful.");
			return dataObj;
		}
	}
	
	console.log(loginInfo.uname + " not found. Login unsuccessful.");
	return null;
}

exports.registerUser = function(user)
{
	var responseData = {};
	var userData = require("./login").checkForLogin(user);
	if (userData)
	{
		responseData.msg = "Username already exists.";
	}
	else
	{
		fs.appendFile("data/users.txt", ";" + JSON.stringify(user), function(err)
		{
			if (err)
				throw err;
			console.log("File updated.");
		});

		responseData.msg = "Thank you for signing up.";
	}
	
	return responseData;
}