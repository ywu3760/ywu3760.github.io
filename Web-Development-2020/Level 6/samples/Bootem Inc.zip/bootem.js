//Constants
const LOW_ID = 10000, HIGH_ID = 99999;
const NUM_EMPLOYEES = 250;
const MIN_AGE = 24, MAX_AGE = 71;
const BASE_SALARY = 32000, AGE_DIFFERENTIAL = 250, ANNUAL_RAISE = 750;
const RETIREMENT_AGE = 62, RETIREMENT_SERVICE = 35;

/*
	The Employee Template
*/
function Employee(id, age, start, salary)
{
	this.employeeId = id;
	this.employeeAge = age;
	this.employeeStartAge = start;
	this.employeeSalary = salary;
}

/*
	generateRandomIDs
	
	Generates a list of 5 digit ID numbers with no duplicates
	
	Parameters:
		howMany - the number IDs to generate
		
	Returns:
		A list of all of the generated ID numbers.
*/
function generateRandomIDs(howMany)
{
	//Create an array with all possible Ids.
	var allIds = [];
	for (var i = LOW_ID; i < HIGH_ID; i++)
	{
		allIds.push(i);
	}
	
	//Create an array for the generated IDs.
	var returnIds = [];
	for (i = 0; i < howMany; i++)
	{
		/*
			Splice a random ID out of the list of all IDs and push it into the returnIds list. By removing the selected ID from the list, we're preventing the possibility of duplicates.
		*/
		var randId = parseInt(Math.random() * allIds.length);
		var selectedId = allIds.splice(randId, 1)[0];
		returnIds.push(selectedId);
	}
	
	return returnIds;
}

/*
	determineSalary
	
	Generates a random salary based on the information in the constants and the parameters.
	
	Parameters:
		startAge - the age of the employee when (s)he was hired.
		currentAge - the age of the employee now.
*/
function determineSalary(startAge, currentAge)
{
	//How long has the employee been with the company?
	var yearsOfService = currentAge - startAge;
	
	/*
		What was the difference between the employee's age when (s)he started and the minimum age required for being hired.
	*/
	var startDifferential = startAge - MIN_AGE;
	
	/*
		In order to determine how much an employee earned when (s)he was hired, multiply the age differential (how much an employee gets for years of experience elsewhere) by the number of years working elsewhere.  Add to that, the base starting salary.
	*/
	var startingSalary = (startDifferential * AGE_DIFFERENTIAL) + BASE_SALARY;
	
	/*
		An employees current salary is his or her starting salary plus the annual raise for each year of service.
	*/
	return startingSalary + (yearsOfService * ANNUAL_RAISE);
}

/*
	isRetirementEligible
	
	Determines whether or not a single employee is eligible for retirement based on the critera defined in the contants.
	
	Parameters:
		employee - the employee whose eligibility is to be determined.
		
	Returns:
		true if the employee is eligible, false if not.
*/			
function isRetirementEligible(employee)
{
	return employee.employeeAge >= RETIREMENT_AGE || employee.employeeAge - employee.employeeStartAge >= RETIREMENT_SERVICE;
}

/*
	getRetirables
	
	Gathers all of the employees who are eligible to retire and puts them into a list.
	
	Returns:
		The list of eligible employees.
*/
function getRetirables()
{
	var retirables = [];
	for (var i = 0; i < employeeList.length; i++)
	{
		if (isRetirementEligible(employeeList[i]))
		{
			retirables.push(employeeList[i]);
		}
	}
	
	return retirables;
}

/*
	isPackageEligible
	
	Determines whether or not a single employee is eligible for an early retirement package based on the critera defined in the contants.
	
	Parameters:
		employee - the employee whose eligibility is to be determined.
		
	Returns:
		true if the employee is eligible, false if not.
*/			
function isPackageEligible(employee, minAge, minSalary)
{
	return employee.employeeAge >= minAge && employee.employeeSalary >= minSalary && !isRetirementEligible(employee);
}

/*
	Figures out which employees are eligible for a package and puts them into a list.
	
	Parameters:
		age - the minimum age requirement for the package
		salary - the minimum salary requirement for the package
		
	Returns:
		The list of eligible employees.
*/
function determinePackage(age, salary)
{
	var packageables = [];
	for (var i = 0; i < employeeList.length; i++)
	{
		if (isPackageEligible(employeeList[i], age, salary))
		{
			packageables.push(employeeList[i]);
		}
	}
	
	return packageables;
}

